import React from "react"
import "./assets/scss/Spinner.scss";

class SpinnerComponent extends React.Component {
  render() {
    return (
        <div className="spinner">
          <div className="wrapper">
            <ul>
              <li></li>
              <li></li>
              <li></li>
              <li></li>
              <li></li>
              <li></li>
              <li></li>
              <li></li>
              <li></li>
              <li></li>
              <li></li>
              <li></li>
              <li></li>
              <li></li>
              <li></li>
              <li></li>
              <li></li>
              <li></li>
              <li></li>
              <li></li>
              <li></li>
              <li></li>
              <li></li>
              <li></li>
              <li></li>
            </ul>
          </div>
        </div>
    )
  }
}

export default SpinnerComponent
