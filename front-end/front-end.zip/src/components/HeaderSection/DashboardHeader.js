import React, { Component } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { Collapse, Dropdown, DropdownMenu, DropdownToggle, Form, Nav, Navbar, NavbarToggler, NavItem } from "reactstrap"

class DashboardHeader extends Component {
    constructor(params) {
        super(params);
        this.state = {
            dropdownOpen: false,
            isOpen: false
        }
    }

    toggle = () => {
        this.setState({
            dropdownOpen : !this.state.dropdownOpen
        })
    }

    navToggle = () => {
    }

    render() {
        return (
            <header className="navbar dashboard-navbar position-absolute top-0">
                <div className="dashboard-logo">
                    <h2 className="m-0"><Link to="/dashboard">TIMECLICK360</Link></h2>
                </div>
                <div className="dashboard-search d-flex">
                    <Form>
                        <input type="text" className="form-control" placeholder="Search Employee" />
                    </Form>
                </div>
                <div className="dashboard-user-navbar">
                    <button className="btn btn-bordered news-button"><i className="fas fa-gift mr-1"></i>New Arrivals<span>(10)</span></button>
                    <Dropdown isOpen={this.state.dropdownOpen} toggle={this.toggle}>
                        <DropdownToggle caret className="user-dropdown-button">
                            {(JSON.parse(localStorage.getItem('current_user'))).name}
                        </DropdownToggle>
                        <DropdownMenu right>
                            <div className="user-dropdown-item"><i className="fas fa-user mr-2"></i>My profile</div>
                            <div className="user-dropdown-item"><i className="fas fa-gift mr-2"></i>New arrivals</div>
                            <div className="user-dropdown-item"><i className="fas fa-info-circle mr-2"></i>Help center</div>
                            <div className="user-dropdown-item"><i className="fas fa-power-off mr-2"></i>Log out</div>
                        </DropdownMenu>
                    </Dropdown>
                </div>
                <Navbar color="light" light expand="md" className="dashboard-header-bar">
                    <NavbarToggler onClick={this.navToggle} />
                    <Collapse isOpen={this.state.isOpen} navbar>
                        <Nav className="mr-auto" navbar>
                            <NavItem>
                                <NavLink to="/dashboard" activeClassName="dash-nav-active">Dashboard</NavLink>
                            </NavItem>
                            <NavItem>
                                <NavLink to="/dashboard-calendar" activeClassName="dash-nav-active">Calendar</NavLink>
                            </NavItem>
                            <NavItem>
                                <NavLink to="/dashboard-requests" activeClassName="dash-nav-active">Requests</NavLink>
                            </NavItem>
                            <NavItem>
                                <NavLink to="/dashboard-presence" activeClassName="dash-nav-active">Presence</NavLink>
                            </NavItem>
                            <NavItem>
                                <NavLink to="/dashboard-documents" activeClassName="dash-nav-active">Documents</NavLink>
                            </NavItem>
                            <NavItem>
                                <NavLink to="/dashboard-team" activeClassName="dash-nav-active">Team</NavLink>
                            </NavItem>
                            <NavItem>
                                <NavLink to="/dashboard-reports" activeClassName="dash-nav-active">Reports</NavLink>
                            </NavItem>
                            <NavItem>
                                <NavLink to="/dashboard-setting" activeClassName="dash-nav-active">Setting</NavLink>
                            </NavItem>
                        </Nav>
                    </Collapse>
                </Navbar>
            </header>
        );
    }
}

export default DashboardHeader;