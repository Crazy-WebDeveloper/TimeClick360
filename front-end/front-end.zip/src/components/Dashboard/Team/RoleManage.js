import React, { Component } from 'react';

class RoleManage extends Component {
    render() {
        return (
            <div>
                
            </div>
        );
    }
}

export default RoleManage;