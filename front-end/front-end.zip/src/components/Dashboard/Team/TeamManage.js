import React, { Component } from 'react';
import { DataGrid } from '@material-ui/data-grid';
import { Button, Row, Col, Form, Label, Modal, ModalBody, Input, ModalHeader, FormGroup } from 'reactstrap';
import Select from 'react-select';
// import { TreeSelect } from 'antd';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { CirclePicker } from 'react-color'
import { connect } from 'react-redux'
import { addPosition, loadPosition, addDepartment, loadDepartment, addPerson, loadEmployees } from "../../../redux/actions/superAdmin"

class TeamManage extends Component {
    constructor() {
        super();
        this.state = {
            columns : [
                { field: 'fullName', headerName: 'Employee', sortable: true, width: 300,
                    renderCell: (params) => {
                        return (
                            <div>{params.row.firstName + " " + params.row.lastName}</div>
                        )
                    }
                },
                { field: 'id', headerName: 'ID', sortable: true, width: 250 },
                { field: 'department', headerName: 'Department', type: 'string', sortable: true, width: 200 },
                { field: 'position', headerName: 'Position', sortable: true },
                { field: 'centers', headerName: 'Centers', sortable: true, width: 150 },
                { field: 'role', headerName: 'Role', sortable: true, width: 200 },
            ],

            isSelectedRow: false,

            // Employee Data
            rows : [],

            // search Employee Data
            searchEmployeeData : [],

            // role Data
            roleData: [
                { value: "Administrator", label: "Administrator" },
                { value: "Responsable", label: "Responsable" },
                { value: "User", label: "User" },
                { value: "Center Administrator", label: "Center Administrator" },
            ],

            // position Data
            positionData : [],
            positionName: "",
            selectedPositionColor: "#f44336",
            
            // modal Bool Var
            isOpenPositionModal: false,
            isOpenDepartmentModal: false,
            isOpenModal: false,

            // responsable data
            responsableData: [
                { value: "1", label: "1" },
                { value: "2", label: "2" },
            ],

            // centers data
            centersData: [
                { value: "nobusiness", label: "nobusiness" }
            ],
            
            // calendar data
            calendarData: [
                { value: "nobusiness", label: "nobusiness" }
            ],
            
            // agreement data
            agreementData: [
                { value: "nobusiness", label: "nobusiness" }
            ],
            
            // schedule data
            scheduleData: [
                { value: "nobusiness", label: "nobusiness" }
            ],
            
            // department data
            departmentData: [],
            departmentName: "",
            pDepartment: "",
            selectedDepartmentColor: "#f44336",
            selectedPDepartment: "",

            // person data
            firstName: "",
            lastName: "",
            email: "",
            birthDay: new Date(),
            position: "",
            department: "",
            role: "",
            responsable: "",
            centers: "",
            calendar: "",
            agreement: "",
            schedule: "",
            startDay: new Date(),
            endDay: new Date(),
        }
    }

    onChange = e => {
        if (e&&e.length > 0) {
            let rows = [];
            for (let i = 0; i < this.props.employeeData.length; i++) {
                for (let j = 0; j < e.length; j++) {
                    if (this.props.employeeData[i]._id === e[j].value) {
                        rows.push(this.props.employeeData[i]);
                    }
                }
            }
            this.setRow(rows, this.state.positionData, this.state.departmentData)
        } else {
            console.log(this.props.employeeData)
            this.setRow(this.props.employeeData, this.state.positionData, this.state.departmentData)
        }
    };

    onChangePositionSelect = (e) => {
        this.setState({
            position: e.value
        })
    }

    onChangeDepartmentSelect = (e) => {
        this.setState({
            department: e
        })
    }
    
    onChangeRoleSelect = (e) => {
        this.setState({
            role: e.value
        })
    }

    onChangeResponseSelect = (e) => {
        this.setState({
            responsable: e.value
        })
    }
    
    onChangeCentersSelect = (e) => {
        console.log(e);
        this.setState({
            centers: e.value
        })
    }

    onChangeCalendarSelect = (e) => {
        this.setState({
            calendar: e.value
        })
    }
    
    onChangeAgreementSelect = (e) => {
        this.setState({
            agreement: e.value
        })
    }

    onChangeScheduleSelect = (e) => {
        this.setState({
            schedule: e.value
        })
    }
    
    onSChangeDepartmentSelect = (e) => {
        this.setState({
            selectedPDepartment: e.value
        })
    }

    modalToggle = () => {
        this.setState({
            isOpenModal: !this.state.isOpenModal
        })
    }

    handleBirthDayChange = (birthDay) => {
        this.setState({ birthDay })
    }
    
    handleStartDayChange = (startDay) => {
        this.setState({ startDay })
    }

    handleEndChange = (endDay) => {
        this.setState({ endDay })
    }

    positionModalToggle = () => {
        this.setState({
            isOpenPositionModal : !this.state.isOpenPositionModal
        })
    }
    
    departmentModalToggle = () => {
        this.setState({
            isOpenDepartmentModal : !this.state.isOpenDepartmentModal
        })
    }

    onChangePositionColor = (color) => {
        this.setState({ selectedPositionColor: color.hex })
    }
    
    onChangeDepartmentColor = (color) => {
        this.setState({ selectedDepartmentColor: color.hex })
    }

    handleSubmitPosition = (e) => {
        e.preventDefault();
        this.props.addPosition({name: this.state.positionName, color: this.state.selectedPositionColor});
        this.positionModalToggle();
    }

    handleSubmitDepartment = e => {
        e.preventDefault();
        this.props.addDepartment({name: this.state.departmentName, parentId: this.state.selectedPDepartment, color: this.state.selectedDepartmentColor});
        this.departmentModalToggle();
    }

    handleAddPersonSubmit = e => {
        e.preventDefault();
        var data = { 
            firstName: this.state.firstName,
            lastName: this.state.lastName, 
            email: this.state.email, 
            birthDay: this.state.birthDay, 
            position: this.state.position, 
            department: this.state.department, 
            role: this.state.role, 
            responsable: this.state.responsable, 
            centers: this.state.centers,
            calendar: this.state.calendar, 
            agreement: this.state.agreement, 
            schedule: this.state.schedule, 
            startDay: this.state.startDay, 
            endDay: this.state.endDay 
        };
        this.props.addPerson(data);
    }

    componentDidMount = () => {
        this.props.loadPosition();
        this.props.loadDepartment();
        this.props.loadEmployees();
    }

    setRow = (employeeData, pData, departmentData) => {
        var empData = []

        for (let i = 0; i < employeeData.length; i++) {
            let data = employeeData[i];
            let depart = "";
            let position = "";
            for (let j = 0; j < departmentData.length; j++) {
                if (data.department === departmentData[j].value) {
                    depart = departmentData[j].label;
                }
            }
            for (let j = 0; j < pData.length; j++) {
                if (data.position === pData[j].value) {
                    position = pData[j].label;
                }
            }
            let obj = {
                id: data._id,
                firstName: data.first_name,
                lastName: data.last_name,
                role: data.role,
                department: depart,
                position: position,
                centers: data.centers
            };
            empData.push(obj);
        }
        
        this.setState({
            rows: empData
        })
    }

    componentDidUpdate = (prevProps, prevState) => {
        if (this.props !== prevProps) {
            var pData = [];
            if (this.props.positionData && this.props.positionData.length > 0) {
                for (let i = 0; i < this.props.positionData.length; i++) {
                    let obj = {
                        value: this.props.positionData[i]._id, label: this.props.positionData[i].name, color: this.props.positionData[i].color
                    }
                    pData.push(obj);
                }
            }

            var departmentData = [];
            if (this.props.departmentData && this.props.departmentData.length > 0) {
                for (let i = 0; i < this.props.departmentData.length; i++) {
                    let obj = {
                        value: this.props.departmentData[i]._id, label: this.props.departmentData[i].name, color: this.props.departmentData[i].color, parentId: this.props.departmentData[i].parentId
                    }
                    departmentData.push(obj);
                }
            }
            
            var searchEmpData = [];
            if (this.props.employeeData&&this.props.employeeData.length !== 0) {
                this.setRow(this.props.employeeData, pData, departmentData);
                
                for (let i = 0; i < this.props.employeeData.length; i++) {
                    let data = this.props.employeeData[i];
                    let sObj = {
                        value: data._id, label: data.first_name + " " + data.last_name
                    }
                    searchEmpData.push(sObj);
                }
            }

            this.setState({
                positionData: pData,
                departmentData: departmentData,
                searchEmployeeData: searchEmpData
            })
        }
    }

    handleTableSelection = (e) => {
        if (e.rowIds > 0) {
            this.setState({
                isSelectedRow: true
            })
        } else {
            this.setState({
                isSelectedRow: true
            })
        }
    }

    render() {
        return (
            <div className="team-manage">
                <div className="team-manage-header">
                    <Select
                        isClearable
                        isSearchable
                        isMulti
                        name="searchEmployee"
                        className="w-25"
                        options={this.state.searchEmployeeData}
                        onChange={(e) =>this.onChange(e)}
                    />
                        <Button color="primary" className="btn-add-person btn-dashboard btn-primary" onClick={() => this.modalToggle()}>Add person</Button>
                    {/* {
                        this.state.isSelectedRow === false ? 
                        :
                        ""
                    } */}
                </div>
                <DataGrid rows={this.state.rows} autoHeight columns={this.state.columns} pageSize={5} onSelectionChange={this.handleTableSelection} checkboxSelection />
                <Modal isOpen={this.state.isOpenModal} toggle={this.modalToggle} size="lg">
                    <ModalHeader toggle={this.modalToggle}>Add person</ModalHeader>
                    <ModalBody>
                        <Form action="#" onSubmit={this.handleAddPersonSubmit}>
                            <Row>
                                <Col>
                                    <FormGroup>
                                        <Label for="exampleEmail">First Name</Label>
                                        <Input type="text" name="firstName" placeholder="First Name" onChange={e => this.setState({firstName: e.target.value})} required />
                                    </FormGroup>
                                </Col>
                                <Col>
                                    <FormGroup>
                                        <Label for="exampleEmail">Last Name</Label>
                                        <Input type="text" name="lastName" placeholder="Last Name" onChange={e => this.setState({lastName: e.target.value})} required />
                                    </FormGroup>
                                </Col>
                            </Row>
                            <Row>
                                <Col>
                                    <FormGroup>
                                        <Label for="exampleEmail">Email</Label>
                                        <Input type="email" name="email" placeholder="Email" onChange={e => this.setState({email: e.target.value})} required />
                                    </FormGroup>
                                </Col>
                                <Col>
                                    <FormGroup className="d-flex flex-column">
                                        <Label for="exampleEmail">Birth Day</Label>
                                        <DatePicker
                                            selected={this.state.birthDay}
                                            onChange={this.handleBirthDayChange}
                                            dateFormat="yyyy-MM-dd"
                                            className="form-control"
                                            required
                                        />
                                    </FormGroup>
                                </Col>
                            </Row>
                            <Row>
                                <Col>
                                    <FormGroup>
                                        <Label for="exampleEmail">Position</Label>
                                        <Select
                                            isClearable
                                            isSearchable
                                            name="Select..."
                                            options={this.state.positionData}
                                            onChange={(e) =>this.onChangePositionSelect(e)}
                                            required
                                        />
                                    </FormGroup>
                                </Col>
                                <Col className="d-flex justify-content-center align-items-center">
                                    <Button className="btn-dashboard btn-primary" onClick={() => this.positionModalToggle()}>Add position</Button>
                                </Col>
                            </Row>
                            <Row>
                                <Col>
                                    <FormGroup>
                                        <Label for="exampleEmail">Department</Label>
                                        <Input type="select" name="select" style={{padding: "8px"}} onChange={e => this.onChangeDepartmentSelect(e.target.value)} required>
                                            <option value="">Select...</option>
                                            {
                                                this.state.departmentData.map((item, i) => (
                                                    <option value={item.value} key={i} style={{padding: 0}}>{item.label}</option>
                                                ))
                                            }
                                        </Input>
                                    </FormGroup>
                                </Col>
                                <Col className="d-flex justify-content-center align-items-center">
                                    <Button className="btn-dashboard btn-primary" onClick={() => this.departmentModalToggle()}>Add department</Button>
                                </Col>
                            </Row>
                            <FormGroup>
                                <Label for="exampleEmail">Role</Label>
                                <Select
                                    isClearable
                                    isSearchable
                                    name="Select..."
                                    options={this.state.roleData}
                                    onChange={(e) =>this.onChangeRoleSelect(e)}
                                    required
                                />
                            </FormGroup>
                            <FormGroup>
                                <Label for="exampleEmail">Responsable</Label>
                                <Select
                                    isClearable
                                    isSearchable
                                    name="Select..."
                                    options={this.state.responsableData}
                                    onChange={(e) =>this.onChangeResponseSelect(e)}
                                    required
                                />
                            </FormGroup>
                            <FormGroup>
                                <Label for="exampleEmail">Centers</Label>
                                <Select
                                    isClearable
                                    isSearchable
                                    name="Select..."
                                    options={this.state.centersData}
                                    onChange={(e) =>this.onChangeCentersSelect(e)}
                                    required
                                />
                            </FormGroup>
                            <FormGroup>
                                <Label for="exampleEmail">Calendar</Label>
                                <Select
                                    isClearable
                                    isSearchable
                                    name="Select..."
                                    options={this.state.calendarData}
                                    onChange={(e) =>this.onChangeCalendarSelect(e)}
                                    required
                                />
                            </FormGroup>
                            <FormGroup>
                                <Label for="exampleEmail">Agreement</Label>
                                <Select
                                    isClearable
                                    isSearchable
                                    name="Select..."
                                    options={this.state.agreementData}
                                    onChange={(e) =>this.onChangeAgreementSelect(e)}
                                />
                            </FormGroup>
                            <FormGroup>
                                <Label for="exampleEmail">Schedule</Label>
                                <Select
                                    isClearable
                                    isSearchable
                                    name="Select..."
                                    options={this.state.scheduleData}
                                    onChange={(e) =>this.onChangeScheduleSelect(e)}
                                />
                            </FormGroup>
                            <Row>
                                <Col>
                                    <FormGroup className="d-flex flex-column">
                                        <DatePicker
                                            selected={this.state.startDay}
                                            onChange={this.handleStartDayChange}
                                            dateFormat="yyyy-MM-dd"
                                            className="form-control"
                                        />
                                    </FormGroup>
                                </Col>
                                <Col>
                                    <FormGroup className="d-flex flex-column">
                                        <DatePicker
                                            selected={this.state.endDay}
                                            onChange={this.handleEndChange}
                                            dateFormat="yyyy-MM-dd"
                                            className="form-control"
                                        />
                                    </FormGroup>
                                </Col>
                            </Row>
                            <Button type="submit" className="btn-add-person btn-dashboard btn-primary my-1 w-100">Accept</Button>
                        </Form>
                    </ModalBody>
                </Modal>
                <Modal isOpen={this.state.isOpenPositionModal} toggle={this.positionModalToggle}>
                    <ModalHeader toggle={this.positionModalToggle}>Add position</ModalHeader>
                    <ModalBody>
                        <Form action="#" onSubmit={this.handleSubmitPosition}>
                            <FormGroup>
                                <Label for="exampleEmail">Name</Label>
                                <Input type="text" name="position" placeholder="Position Name" value={this.state.positionName} onChange={(e) => this.setState({positionName: e.target.value})} required />
                            </FormGroup>
                            <div style={{width: "100%", height: "50px", background: this.state.selectedPositionColor, margin: "10px 0"}}></div>
                            <CirclePicker className="w-100 mb-1" onChangeComplete={this.onChangePositionColor} />
                            <Button className="btn-add-person btn-dashboard btn-primary" type="submit">Accept</Button>{' '}
                            <Button className="btn-add-person btn-dashboard btn-primary" onClick={() => this.positionModalToggle()}>Cancel</Button>{' '}
                        </Form>
                    </ModalBody>
                </Modal>
                <Modal isOpen={this.state.isOpenDepartmentModal} toggle={this.departmentModalToggle}>
                    <ModalHeader toggle={this.departmentModalToggle}>Add position</ModalHeader>
                    <ModalBody>
                        <Form action="#" onSubmit={this.handleSubmitDepartment}>
                            <FormGroup>
                                <Label for="exampleEmail">Department name</Label>
                                <Input type="text" placeholder="Department Name" value={this.state.departmentName} onChange={(e) => this.setState({departmentName: e.target.value})} required />
                            </FormGroup>
                            <FormGroup>
                                <Label for="exampleEmail">Parent department</Label>
                                <Select
                                    isClearable
                                    isSearchable
                                    name="Select Department"
                                    options={this.state.departmentData}
                                    onChange={(e) =>this.onSChangeDepartmentSelect(e)}
                                />
                            </FormGroup>
                            <div style={{width: "100%", height: "50px", background: this.state.selectedDepartmentColor, margin: "10px 0"}}></div>
                            <CirclePicker className="w-100 mb-1" onChangeComplete={this.onChangeDepartmentColor} />
                            <Button className="btn-add-person btn-dashboard btn-primary" type="submit">Accept</Button>{' '}
                            <Button className="btn-add-person btn-dashboard btn-primary" onClick={() => this.departmentModalToggle()}>Cancel</Button>{' '}
                        </Form>
                    </ModalBody>
                </Modal>
            </div>
        );
    }
}

const loadData = (state) => {
    return {
        positionData: state.superAdmin.superAdmin.positionData,
        departmentData: state.superAdmin.superAdmin.departmentData,
        employeeData: state.superAdmin.superAdmin.employees,
    }
}

export default connect(loadData, { addPosition, loadPosition, addDepartment, loadDepartment, addPerson, loadEmployees })(TeamManage);