import React, { Component } from 'react';

class Reports extends Component {
    render() {
        return (
            <div className="bg-gray dashboard" id="dashboard-reports">
                
            </div>
        );
    }
}

export default Reports;