import React, { Component } from 'react';

class Setting extends Component {
    render() {
        return (
            <div className="bg-gray dashboard" id="dashboard-setting">
                
            </div>
        );
    }
}

export default Setting;