import React, { Component } from 'react';

class Documents extends Component {
    render() {
        return (
            <div className="bg-gray dashboard" id="dashboard-documents">
                
            </div>
        );
    }
}

export default Documents;