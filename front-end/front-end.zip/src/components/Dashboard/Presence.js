import React, { Component } from 'react';

class Presence extends Component {
    render() {
        return (
            <div className="bg-gray dashboard" id="dashboard-presence">
                
            </div>
        );
    }
}

export default Presence;