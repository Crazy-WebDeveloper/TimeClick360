export const Root = {
    serverUrl : "http://localhost:2127/",
    token : "timeclick_token"
}