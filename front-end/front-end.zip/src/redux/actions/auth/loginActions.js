// import { history } from "../../../history"
import axios from "axios"
import Cookies from "js-cookie"
import { store } from 'react-notifications-component';
// import jwt_decode from "jwt-decode";
import { Root } from "../../../config/rootConfig";

export const loginWithJWT = user => {
  return dispatch => {
    axios.post(Root.serverUrl + "users/signin", user)
      .then(response => {
        if (response.data.status) {
          Cookies.set(Root.token, response.data.data.token, { path : "timeclick"})
          localStorage.setItem('current_user', JSON.stringify(response.data.data.data));
          window.location.href = "/";
        } else {
          store.addNotification({
            title: "Error!",
            message: response.data.data,
            type: "danger",
            insert: "top",
            container: "top-right",
            animationIn: ["animate__animated", "animate__lightSpeedInRight"],
            animationOut: ["animate__animated", "animate__lightSpeedOutRight"],
            dismiss: {
              duration: 5000,
              onScreen: true,
              pauseOnHover: true,
              showIcon : true
            }
          });
        }
      })
  }
}

export const sessionCheck = () => {
  return dispatch => {
    var token = Cookies.get(Root.token, { path : "timeclick" });
    if (token) {
      dispatch({
        type : "JWT_AUTH_CHECK",
        data : true
      })
    } else {
      dispatch({
        type : "JWT_AUTH_CHECK",
        data : false
      })
    }
  }
}

export const logOut = () => {
  Cookies.remove(Root.token, {path : "timeclick"});
  localStorage.removeItem('current_user')
  window.location.href = "/"
}