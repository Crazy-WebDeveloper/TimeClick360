import axios from "axios"
import { store } from 'react-notifications-component';
import { Root } from "../../../config/rootConfig";

export const addPosition = (data) => {
    return async dispatch => {
        var response = await axios.post(Root.serverUrl + "superAdmin/addPosition", data);
        if (response.data.status) {
            dispatch({
                type: "POSITION_DATA",
                data: response.data.data
            })
        } else {
            store.addNotification({
                title: "Error!",
                message: response.data.data,
                type: "danger",
                insert: "top",
                container: "top-right",
                animationIn: ["animate__animated", "animate__lightSpeedInRight"],
                animationOut: ["animate__animated", "animate__lightSpeedOutRight"],
                dismiss: {
                    duration: 5000,
                    onScreen: true,
                    pauseOnHover: true,
                    showIcon : true
                }
            });
        }
    }
}

export const loadPosition = () => {
    return async dispatch => {
        var response = await axios.post(Root.serverUrl + "superAdmin/loadPosition");
        if (response.data.status) {
            dispatch({
                type: "POSITION_DATA",
                data: response.data.data
            })
        } else {
            store.addNotification({
                title: "Error!",
                message: response.data.data,
                type: "danger",
                insert: "top",
                container: "top-right",
                animationIn: ["animate__animated", "animate__lightSpeedInRight"],
                animationOut: ["animate__animated", "animate__lightSpeedOutRight"],
                dismiss: {
                    duration: 5000,
                    onScreen: true,
                    pauseOnHover: true,
                    showIcon : true
                }
            });
        }
    }
}

export const addDepartment = (data) => {
    return async dispatch => {
        var response = await axios.post(Root.serverUrl + "superAdmin/addDepartment", data);
        if (response.data.status) {
            dispatch({
                type: "DEPARTMENT_DATA",
                data: response.data.data
            })
        } else {
            store.addNotification({
                title: "Error!",
                message: response.data.data,
                type: "danger",
                insert: "top",
                container: "top-right",
                animationIn: ["animate__animated", "animate__lightSpeedInRight"],
                animationOut: ["animate__animated", "animate__lightSpeedOutRight"],
                dismiss: {
                    duration: 5000,
                    onScreen: true,
                    pauseOnHover: true,
                    showIcon : true
                }
            });
        }
    }
}

export const loadDepartment = () => {
    return async dispatch => {
        var response = await axios.post(Root.serverUrl + "superAdmin/loadDepartment");
        if (response.data.status) {
            dispatch({
                type: "DEPARTMENT_DATA",
                data: response.data.data
            })
        } else {
            store.addNotification({
                title: "Error!",
                message: response.data.data,
                type: "danger",
                insert: "top",
                container: "top-right",
                animationIn: ["animate__animated", "animate__lightSpeedInRight"],
                animationOut: ["animate__animated", "animate__lightSpeedOutRight"],
                dismiss: {
                    duration: 5000,
                    onScreen: true,
                    pauseOnHover: true,
                    showIcon : true
                }
            });
        }
    }
}

export const addPerson = (data) => {
    return async dispatch => {
        var response = await axios.post(Root.serverUrl + "superAdmin/addPerson", data);
        if (response.data.status) {
            dispatch({
                type: "EMPLOYEE_DATA",
                data: response.data.data
            })
        } else {
            store.addNotification({
                title: "Error!",
                message: response.data.data,
                type: "danger",
                insert: "top",
                container: "top-right",
                animationIn: ["animate__animated", "animate__lightSpeedInRight"],
                animationOut: ["animate__animated", "animate__lightSpeedOutRight"],
                dismiss: {
                    duration: 5000,
                    onScreen: true,
                    pauseOnHover: true,
                    showIcon : true
                }
            });
        }
    }
}

export const loadEmployees = () => {
    return async dispatch => {
        var response = await axios.post(Root.serverUrl + "superAdmin/loadEmployees");
        if (response.data.status) {
            dispatch({
                type: "EMPLOYEE_DATA",
                data: response.data.data
            })
        } else {
            store.addNotification({
                title: "Error!",
                message: response.data.data,
                type: "danger",
                insert: "top",
                container: "top-right",
                animationIn: ["animate__animated", "animate__lightSpeedInRight"],
                animationOut: ["animate__animated", "animate__lightSpeedOutRight"],
                dismiss: {
                    duration: 5000,
                    onScreen: true,
                    pauseOnHover: true,
                    showIcon : true
                }
            });
        }
    }
}