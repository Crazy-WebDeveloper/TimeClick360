export const superAdmin = (state = {},action) => {
    switch (action.type) {
      case "POSITION_DATA": {
        return { ...state, positionData : action.data }
      }
      case "DEPARTMENT_DATA": {
        return { ...state, departmentData : action.data }
      }
      case "EMPLOYEE_DATA": {
        return { ...state, employees : action.data }
      }
      default: {
        return state
      }
    }
}
  