export const login = (state = {},action) => {
  switch (action.type) {
    case "JWT_AUTH_LOGIN": {
      return { ...state, authData : action.data }
    }
    case "JWT_AUTH_CHECK": {
      return { ...state, authCheck : action.data }
    }
    default: {
      return state
    }
  }
}
