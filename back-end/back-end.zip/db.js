module.exports = {
    "ServerPort" : "2127",
    "BASEURL" : __dirname+"/client/upload/",
    "BASEURL1" : __dirname+"/client/upload1/",
    "DIR" : __dirname,
    "ADMINPASSMETHOD" : "admin",
}