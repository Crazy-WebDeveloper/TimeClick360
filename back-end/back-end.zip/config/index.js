module.exports = {
    DBCONNECT : "mongodb://127.0.0.1:27017/?compressors=disabled&gssapiServiceName=mongodb",
    DevDB : "mongodb://localhost:27017/timeclick360",
    Domain : "timeclick360.com"
}